/////////////////////////////////////////////////////////////////////////////
////                        		                            	     ////
////                                                              	  	 ////
/////////////////////////////////////////////////////////////////////////////
////                                                                	 ////
////    delayMicSec - SoftWare Delay in 43 MicroSecond for Each Counter	 ////
////                                                                	 ////
////    delayMicSec - SoftWare Delay in 1 MilliSecond for Each Counter	 ////
////                                                                     ////
////    LcdInit - Configures the 16X2 Lcd Display peripheral             ////
////                                                                 	 ////
////    LcdFunction - Sends a message/command to LCD Display             ////
////                                                            	     ////
////    LcdStrFunction - Sends ConsecutiVe String to LCD DisplAy         ////
////                        	                                         ////
////    AnalogToDigit - ADC0809 Analog to Digital ConveRsion Function    ////
////                        	                                         ////
////    	/*------------------Pin DetAils------------------*/          ////
////                                                                 	 ////
////    16x2 Lcd display 8-Bit Data Mode P2-DataLine 			  	 	 ////
////    MSB(P2.7) to MSB(D7) & LSB(P2.0) to LSB(D0)                      ////
////    Lcd display 8-Bit Data Mode P3.2-Register Selsect CtrlLine  	 ////
////    Lcd displAy 8-Bit Data Mode P3.3-Read Write Selsect CtrlLine 	 ////
////    Lcd display 8-Bit Data Mode P3.4-Enable Selsect CtrlLine    	 ////
////                                                                 	 ////
////    Adc0809 Parallel Communication P0-DataLine 				  	 	 ////
////    Adc0809 Ctrl Line P1.0 - ChaSel0 CtrlLine		 			 	 ////
////    Adc0809 Ctrl Line P1.1 - ChaSel1 CtrlLine 	 					 ////
////    Adc0809 Ctrl Line P1.2 - ChaSel2 CtrlLine    	 				 ////
////                                                                 	 ////
////////////////////////////////////////////////////////////////////////////j

	#include <REGX52.H>	   /* AT89S52 Header File*/
	
	#define LCDDATALINE P2 /* LCD Display DataLine from PORT_2 */
	#define LCDCMD 0	   /* LCD REG_SEL Macro Command*/
	#define LCDDATA 1 	   /* LCD REG_SEL Macro Data*/

	sbit RegSel = P3^2;		/* Register Select CTRL Pin for LCD from PORT_3.2 Pin */
	sbit ReadWrite = P3^3;	/* Read Write CTRL Pin for LCD from PORT_3.3 Pin */
	sbit Enable = P3^4;		/* Enable CTRL Pin for LCD from PORT_3.4 Pin */

	#define	ADCDATA P0 	/* Adc Data Cahnnel PORT P0 */

	sbit ChaSel0 = P1^0;	/* Channel 0  Pin P1-0th Pin	*/
	sbit ChaSel1 = P1^1;	/* Channel 1  Pin P1-1st Pin	*/
	sbit ChaSel2 = P1^2;	/* Channel 2  Pin P1-2nd Pin	*/

	unsigned long int AdcValue=0;  /*  -Hint-  ADC Store Value Must be in unsigned long int*/
		
	void delayMicSec(unsigned int DelayValue) /* 43 MicroSec delay for Each DelayValue Count Value */
	{
		unsigned int DelayCount;
		for(DelayCount =0 ;DelayCount <= DelayValue; DelayCount++);
	}
	void delayMilliSec(unsigned int DelayValue) /* 1.09 Milli Second delay for Each DelayValue Count Value */
	{
		unsigned int OuterDelayCount,InnerDelayCount;
		for(OuterDelayCount =0 ; OuterDelayCount <= DelayValue; OuterDelayCount++)
		{ for(InnerDelayCount =0 ; InnerDelayCount <= 113; InnerDelayCount++);	}
	}

	unsigned char AnalogToDigit(unsigned char AdcChannel)
	{
			ChaSel0 = AdcChannel & 0x01;  					   /*selecting the channel*/
			ChaSel1 = AdcChannel & 0x02;
			ChaSel2 = AdcChannel & 0x04;	
			delayMilliSec(100);
			return ADCDATA;				
	}

	void LcdFunction(unsigned char LcdChar, unsigned int RegselVal)				/* LCD Display for command and data Function */
	{
		RegSel = RegselVal;		  /* RegselVal = 0 => LCD Command, RegselVal = 1 => LCD Data */	  		
		ReadWrite = 0;		 	  /* Write Mode */				
		delayMicSec(1);
		LCDDATALINE = LcdChar;	  /* send the Data to PORT*/		
		Enable = 1;				  /* Enable  */			
		delayMilliSec(1);		  /* 10 Milli Second Delay */			
		Enable = 0;				  /* Disable */		
	}
	
	void LcdInit(void)	 			      /* LCD Initialization Function */
	{
		LcdFunction(0x38, LCDCMD);		  /* 8-Bit data 2-line mode  */
		LcdFunction(0x0C, LCDCMD);		  /* Display ON, Cursor OFF */
		LcdFunction(0x01, LCDCMD);		  /* Clear Display */
	}
	
	void LcdStrFunction(unsigned char *FromalArgu)	 /* Consecutive Send the Data to LCD Display using Pointer*/
	{
		while(*FromalArgu != '\0') 
		{		LcdFunction(*(FromalArgu++), LCDDATA);		 }	
	}

	void LcdDecimalToAscii(unsigned long int FormalArgu)
	{
		LcdFunction(((FormalArgu/100)+0x30),LCDDATA);
		LcdFunction((((FormalArgu/10)%10)+0x30),LCDDATA);
		LcdFunction(((FormalArgu%10)+0x30),LCDDATA);
	}

	bit LcdClear1=0;
	bit LcdClear2=0;
	void main()
	{
	LcdInit();
	delayMilliSec(10);  	
	while(1)
		{
			AdcValue = AnalogToDigit(2);  			/* Store ADC Value */
			LcdFunction(0xC0,LCDCMD);				/* Starting Position of Lcd Display */
			LcdStrFunction("Z=");		  			/* Lcd Display will Display "Z=" */
			LcdDecimalToAscii(AdcValue);			/* Decimal to ASCII Conversion */
			AdcValue =0;
		}
	}	
	
	
	
	
	
