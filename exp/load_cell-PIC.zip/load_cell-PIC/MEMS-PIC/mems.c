					  		/*	onlysupport.co.in                                        
										Displaying MEMS Sensor Value                                    
										Hi-Tech Compiler      
										Frequency--------->10MHZ  */

#include<pic.h>		//----->>>>>    Including Header File pic.h for using Registers
#define RS RE2
#define RW RE1
#define EN RE0
#define D4 RD4
#define D5 RD5
#define D6 RD6
#define D7 RD7
#define mems RC0
#define _XTAL_FREQ 1000000

void Lcd4_Port(char a)
{
	if(a & 1)
 		D4 = 1;
	else 
		D4 = 0;
	
	if(a & 2)
		D5 = 1;
	else
		D5 = 0;
	
	if(a & 4)
		D6 = 1;
	else
		D6 = 0;
	
	if(a & 8)
		D7 = 1;
	else
		D7 = 0;
}
void Lcd4_Cmd(char a)
{ 
	RS = 0;             // => RS = 0
	RW = 0;
	Lcd4_Port(a);
	EN  = 1;             // => E = 1
  __delay_ms(4);
    EN  = 0;             // => E = 0
}

Lcd4_Clear()
{
	Lcd4_Cmd(0);
	Lcd4_Cmd(1);
}

void Lcd4_Set_Cursor(char a, char b)
{
	char temp,z,y;
	if(a == 1)
	{
	  temp = 0x80 + b;
		z = temp>>4;
		y = (0x80+b) & 0x0F;
		Lcd4_Cmd(z);
		Lcd4_Cmd(y);
	}
	else if(a == 2)
	{
		temp = 0xC0 + b;
		z = temp>>4;
		y = (0xC0+b) & 0x0F;
		Lcd4_Cmd(z);
		Lcd4_Cmd(y);
	}
}

void Lcd4_Init()
{
Lcd4_Port(0x00);
   __delay_ms(20);
  Lcd4_Cmd(0x03);
	__delay_ms(5);
  Lcd4_Cmd(0x03);
	__delay_ms(11);
  Lcd4_Cmd(0x03);
  /////////////////////////////////////////////////////
  Lcd4_Cmd(0x02);    
	Lcd4_Cmd(0x02);
  	Lcd4_Cmd(0x08); 	
	Lcd4_Cmd(0x00); 
	Lcd4_Cmd(0x0C);     
  Lcd4_Cmd(0x00);    
  Lcd4_Cmd(0x06);   
}

void Lcd4_Write_Char(char a)
{
   char temp,y;
   temp = a&0x0F; 
   y = a&0xF0;	
	 RS = 1;             // => RS = 1
	 RW = 0;
   	Lcd4_Port(y>>4);             //Data transfer
	 EN = 1;
	 __delay_ms(5);
	 EN = 0;
	 Lcd4_Port(temp);
	 EN = 1;
	 __delay_ms(5);
	 EN = 0;
}

void Lcd4_Write_String(char *a)
{
	int i;
	for(i=0;a[i]!='\0';i++)
	 Lcd4_Write_Char(a[i]);
}

void Lcd4_Shift_Right()
{
	Lcd4_Cmd(0x01);
	Lcd4_Cmd(0x0C);
}

void Lcd4_Shift_Left()
{
	Lcd4_Cmd(0x01);
	Lcd4_Cmd(0x08);
}
//End LCD 4 Bit Interfacing Functions

void Delay(unsigned int del)
{
	while(del--);
} 

				/******************Port Initialization Function******************/
void Port_Init(){
	TRISA = 7;	//----->>>>> Selecting RA0,RA1,RA2 as I/P for Connecting X,Y,Z MEMS
	TRISD = 0;	//----->>>>> PORTD as Output for Lcd Data Transfer
	TRISE = 0;	//----->>>>> PORTE as Output for Lcd Control Signals 
}
unsigned int Adc_Ch_Sel(char i){
	switch(i){
		case 0:
			CHS2 = 0;		//
			CHS1 = 0;		//	Choosing 0th Channel
			CHS0 = 0;		//
			break;
		case 1:
			CHS2 = 0;		//
			CHS1 = 0;		//	Choosing 1st Channel
			CHS0 = 1;		//
			break;
		case 2:
			CHS2 = 0;		//
			CHS1 = 1;		//	Choosing 2nd Channel
			CHS0 = 0;		//
			break;     
	}
	Delay(255);				
	GODONE=1;			//----->>>>> if GODONE = 1 means,Adc Conversion Starts
	while(GODONE);			//----->>>>> Waiting for Conversion to Complete
	return (ADRESL+(ADRESH<<8));	//----->>>>> Storing 10bit Converted Digital value in these Two Registers
}
void Lcd_Whole_Number(unsigned int number,unsigned int i)
{
	unsigned char temp;
	for(;i>=1;i/=10)
{
		temp = number / i;
	Lcd4_Write_Char	(temp+48);
		number %= i;
	}
}

				/****************ADC Configuration Function********************/

void Adc_Config(){
	ADCON0 = 1;	 //----->>>>> Turning On The Adc Module
	ADCON1 = 0X82;	 //----->>>>> Choosing AN5,AN6,AN7 as Digital and remaining as Analog channels 
}

				/*******************Main Function************************/

void main(){
	unsigned int Adc;
	Port_Init();			//----->>>>> Setting Direction
	Adc_Config();			//----->>>>> ADC Configuration
	Delay(65000);

	Delay(255);
    Lcd4_Set_Cursor(1,0);		//----->>>>> Lcd 1st Line and 1st Position
	Lcd4_Write_String("X=");
	Lcd4_Set_Cursor(1,7);		//----->>>>> Lcd 1st Line and 8th Position
	Lcd4_Write_String("Y=");
	Lcd4_Set_Cursor(2,0);		//----->>>>> Lcd 2nd Line and 1st Position
	Lcd4_Write_String("Z="); 
	while(1){				
		Adc=Adc_Ch_Sel(0);	//----->>>>> Selecting 0th Analog Channel For Connecting Mem's X Position
		Lcd4_Set_Cursor(1,2);	//----->>>>> Forcing Cursor to 1st line and 3rd Position
		Delay(10000);
		Lcd_Whole_Number(Adc,100);//----->>>>> Function for converting Whole Number into Single Charcter
	}
}
